# Copyright (c) 2018 Czirkos Zoltan. MIT license, see LICENSE file.

from .colors import *
from .printer import *
from .getch import *
from .keys import *

colorama.init()
